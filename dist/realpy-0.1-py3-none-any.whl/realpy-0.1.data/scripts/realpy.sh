     

#!/usr/bin/env python

echo "hey there, this is my first pip package"
